// ../redact/src/redact.ts
var PLACEHOLDERS = {
  otp: "[OTP]",
  nric: "[ID]",
  card: "[CARD]",
  account: "[ACCOUNT]",
  phone: "[PHONE]",
  email: "[EMAIL]",
  wallet: "[WALLET]",
  url: "[LINK]"
};
var RULES = [
  // Structured identifiers first — they contain digits that the looser
  // numeric rules below would otherwise chew into.
  { kind: "email", pattern: /\b[\w.+-]+@[\w-]+\.[\w.-]+\b/g },
  // Crypto addresses (EVM 40-hex and Sui 64-hex).
  { kind: "wallet", pattern: /\b0x[a-fA-F0-9]{40,64}\b/g },
  // One-time codes. "your TAC is 123456", "OTP: 8842". TAC is the
  // Malaysian term and appears constantly in local scam scripts.
  {
    kind: "otp",
    pattern: /\b(?:otp|tac|pin|passcode|verification code|code)\b[^0-9]{0,15}\d{4,8}\b/gi
  },
  // Malaysian NRIC: YYMMDD-PB-###G, with or without separators.
  { kind: "nric", pattern: /\b\d{6}[-\s]?\d{2}[-\s]?\d{4}\b/g },
  // International phone, matched WHOLE. Ordered before the numeric
  // rules so "+60 12-345 6789" cannot be redacted in part, which would
  // leave the country code and prefix behind — still identifying.
  { kind: "phone", pattern: /\+\d{1,3}[\s-]?\d(?:[\s-]?\d){5,12}(?!\d)/g },
  // Payment cards: 14–19 digits. Below that is treated as an account,
  // since local bank accounts are commonly 10–13.
  { kind: "card", pattern: /\b\d(?:[ -]?\d){13,18}(?!\d)/g },
  // Local mobile format, e.g. 012-345 6789.
  { kind: "phone", pattern: /\b0\d{1,2}[\s-]?\d{3,4}[\s-]?\d{4}(?!\d)/g },
  // Bank accounts: runs of 8–13 digits that survived the above, WITH or
  // WITHOUT separators — same shape as the card rule above.
  //
  // This used to be `\b\d{8,13}\b`, bare digits only, which left a hole
  // exactly where account numbers are usually written. `512088776655`
  // was stripped but `5140-2288-9911` — the same number, grouped the way
  // a person types one — passed through untouched and reached the model,
  // because it is too short for the 14–19 digit card rule and the account
  // rule could not see past the dashes.
  { kind: "account", pattern: /\b\d(?:[ -]?\d){7,12}(?!\d)/g }
];
function redactUrls(text, removed) {
  return text.replace(/\bhttps?:\/\/([^\s/]+)(\/\S*)?/gi, (_match, host, path) => {
    if (!path || path === "/") return `${PLACEHOLDERS.url}(${host})`;
    removed.url = (removed.url ?? 0) + 1;
    return `${PLACEHOLDERS.url}(${host})`;
  });
}
function protectAmounts(text) {
  const amounts = [];
  const masked = text.replace(
    /\b(?:rm|myr|sgd|usd|s\$|\$|£|€)\s?\d[\d,]*(?:\.\d{1,2})?\b/gi,
    (match) => {
      amounts.push(match);
      return `\0AMT${amounts.length - 1}\0`;
    }
  );
  return {
    text: masked,
    restore: (s) => s.replace(/\u0000AMT(\d+)\u0000/g, (_m, i) => amounts[Number(i)])
  };
}
function redact(message) {
  const removed = {};
  const { text: protectedText, restore } = protectAmounts(message);
  let out = redactUrls(protectedText, removed);
  for (const { kind, pattern } of RULES) {
    out = out.replace(pattern, (match) => {
      if (match.includes("[")) return match;
      removed[kind] = (removed[kind] ?? 0) + 1;
      return PLACEHOLDERS[kind];
    });
  }
  return { text: restore(out), removed };
}

// src/adapters.ts
function normaliseText(raw) {
  return raw.replace(/\s+/g, " ").trim();
}
function messageKey(element, text) {
  const own = element.getAttribute("data-id") ?? element.closest("[data-id]")?.getAttribute("data-id") ?? null;
  return own ? `id:${own}` : `text:${text}`;
}
var SCORED_ATTR = "data-shou-scored";
var isScored = (element) => element.hasAttribute(SCORED_ATTR);
var markScored = (element) => element.setAttribute(SCORED_ATTR, "1");
function parseWhatsAppDataId(dataId) {
  if (!dataId) return null;
  const parts = dataId.split("_");
  if (parts.length < 3) return null;
  const [fromMe, chatJid] = parts;
  if (fromMe !== "true" && fromMe !== "false") return null;
  if (!chatJid) return null;
  return { fromMe: fromMe === "true", chatJid };
}
function firstMatch(doc, selectors) {
  for (const selector of selectors) {
    const found = doc.querySelector(selector);
    if (found) return found;
  }
  return null;
}
var OUTGOING_ICONS = '[data-icon="msg-check"], [data-icon="msg-dblcheck"], [data-icon="msg-time"]';
function messageDirection(element) {
  const parsed = parseWhatsAppDataId(
    element.getAttribute("data-id") ?? element.closest("[data-id]")?.getAttribute("data-id")
  );
  if (parsed) return parsed.fromMe ? "out" : "in";
  return element.querySelector(OUTGOING_ICONS) ? "out" : null;
}
var whatsapp = {
  site: "web.whatsapp.com",
  root: (doc) => {
    const panel = firstMatch(doc, [
      "#main",
      '[data-testid="conversation-panel-messages"]',
      'div[role="application"]'
    ]);
    if (panel) return panel;
    return doc.querySelector('[data-testid="msg-container"], [data-id]') ? doc.body : null;
  },
  threadKey: (doc) => {
    const header = firstMatch(doc, ["#main header", '[data-testid="conversation-info-header"]']);
    const titled = header?.querySelector("[title]")?.getAttribute("title")?.trim();
    if (titled) return titled;
    const root = doc.querySelector("#main") ?? doc;
    for (const el of root.querySelectorAll("[data-id]")) {
      const parsed = parseWhatsAppDataId(el.getAttribute("data-id"));
      if (parsed) return parsed.chatJid;
    }
    const headerText = normaliseText(header?.textContent ?? "");
    return headerText || null;
  },
  incoming: (root) => {
    const candidates = /* @__PURE__ */ new Set([
      ...root.querySelectorAll('[data-testid="msg-container"]'),
      ...root.querySelectorAll("div.message-in"),
      ...root.querySelectorAll('[data-id^="false_"]')
    ]);
    const outermost = [...candidates].filter(
      (el) => ![...candidates].some((other) => other !== el && other.contains(el))
    );
    const nodes = [];
    const seenKeys = /* @__PURE__ */ new Set();
    for (const bubble of outermost) {
      if (isScored(bubble)) continue;
      if (messageDirection(bubble) === "out") continue;
      const spans = bubble.querySelectorAll("span.selectable-text");
      if (!spans.length) continue;
      const text = normaliseText(
        Array.from(spans, (s) => s.innerText ?? s.textContent ?? "").join(" ")
      );
      if (!text) continue;
      const key = messageKey(bubble, text);
      if (seenKeys.has(key)) continue;
      seenKeys.add(key);
      nodes.push({ element: bubble, text, key });
    }
    return nodes;
  }
};
var messenger = {
  site: "messenger.com",
  root: (doc) => doc.querySelector('[role="main"]'),
  threadKey: (doc) => {
    const heading = doc.querySelector('[role="main"] h1, [role="main"] [role="heading"]');
    return normaliseText(heading?.textContent ?? "") || null;
  },
  incoming: (root) => {
    const nodes = [];
    for (const row of root.querySelectorAll('[role="row"]')) {
      if (isScored(row)) continue;
      const label = row.getAttribute("aria-label") ?? row.textContent ?? "";
      if (/^\s*you sent\b/i.test(label)) continue;
      const text = normaliseText(row.innerText ?? row.textContent ?? "");
      if (!text || text.split(" ").length < 3) continue;
      nodes.push({ element: row, text, key: messageKey(row, text) });
    }
    return nodes;
  }
};
var telegram = {
  site: "web.telegram.org",
  root: (doc) => firstMatch(doc, [
    ".bubbles",
    // /k/
    ".MessageList",
    // /a/
    ".messages-container",
    // /k/, older
    '[class*="MessageList"]'
  ]),
  threadKey: (doc) => {
    const title = firstMatch(doc, [
      ".chat-info .peer-title",
      // /k/
      ".ChatInfo .title",
      // /a/
      ".chat-info .title",
      ".sidebar-header .peer-title"
    ]);
    const text = normaliseText(title?.textContent ?? "");
    return text || null;
  },
  incoming: (root) => {
    const candidates = /* @__PURE__ */ new Set([
      ...root.querySelectorAll(".bubble"),
      // /k/
      ...root.querySelectorAll(".Message")
      // /a/
    ]);
    const outermost = [...candidates].filter(
      (el) => ![...candidates].some((other) => other !== el && other.contains(el))
    );
    const nodes = [];
    const seenKeys = /* @__PURE__ */ new Set();
    for (const bubble of outermost) {
      if (isScored(bubble)) continue;
      if (bubble.classList.contains("is-out") || bubble.classList.contains("own")) continue;
      if (bubble.classList.contains("service") || bubble.classList.contains("is-date") || bubble.classList.contains("ServiceMessage")) {
        continue;
      }
      const textEl = bubble.querySelector(".message, .text-content");
      const raw = textEl ?? bubble;
      const text = normaliseText(raw.innerText ?? raw.textContent ?? "");
      if (!text) continue;
      const key = messageKey(bubble, text);
      if (seenKeys.has(key)) continue;
      seenKeys.add(key);
      nodes.push({ element: bubble, text, key });
    }
    return nodes;
  }
};
var ADAPTERS = [whatsapp, messenger, telegram];
function pickAdapter(host) {
  return ADAPTERS.find((adapter2) => host === adapter2.site || host.endsWith(`.${adapter2.site}`)) ?? null;
}
function describeFailure(adapter2, doc) {
  const root = adapter2.root(doc);
  if (!root) return `SHOU: no open conversation found on ${adapter2.site} \u2014 selectors may have changed (see src/adapters.ts)`;
  if (!adapter2.threadKey(doc)) return `SHOU: found the conversation panel but not its title on ${adapter2.site} \u2014 see src/adapters.ts`;
  return null;
}

// src/shared.ts
var TIER_EMOJI = { LOW: "\u{1F7E2}", MEDIUM: "\u{1F7E1}", HIGH: "\u{1F534}" };
var TIER_PLAIN = {
  LOW: "Nothing unusual in this chat.",
  MEDIUM: "Something about this chat looks off. A transfer here will wait, and your trusted contact will be told.",
  HIGH: "This looks like a scam. If you try to send money now, someone you trust has to approve it first."
};

// src/content.ts
var adapter = pickAdapter(location.host);
if (adapter) void start(adapter);
async function sessionIdFor(threadKey) {
  const bytes = new TextEncoder().encode(`${location.host}|${threadKey}`);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  const hex = Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
  return `shou-${hex.slice(0, 24)}`;
}
var BADGE_CLASS = "shou-badge";
function styleOnce() {
  if (document.getElementById("shou-style")) return;
  const style = document.createElement("style");
  style.id = "shou-style";
  style.textContent = `
    .${BADGE_CLASS}{display:inline-flex;align-items:center;gap:4px;margin-left:6px;padding:1px 7px;
      border-radius:999px;font:600 11px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
      vertical-align:middle;white-space:nowrap;cursor:help;border:1px solid transparent}
    .${BADGE_CLASS}[data-tier="LOW"]{background:#e8f6ef;color:#0f7b4f;border-color:#c4e5d5}
    .${BADGE_CLASS}[data-tier="MEDIUM"]{background:#fdf3e0;color:#8a5800;border-color:#f0dcb4}
    .${BADGE_CLASS}[data-tier="HIGH"]{background:#fdecea;color:#b3261e;border-color:#f3c9c5}
    .${BADGE_CLASS}[data-tier="PENDING"]{background:#eef1f5;color:#5d6674;border-color:#e3e6ea}
  `;
  (document.head ?? document.documentElement).append(style);
}
function attachBadge(element) {
  const existing = element.querySelector(`.${BADGE_CLASS}`);
  if (existing) return existing;
  const badge = document.createElement("span");
  badge.className = BADGE_CLASS;
  badge.dataset.tier = "PENDING";
  badge.textContent = "\u22EF";
  badge.title = "SHOU is checking this message";
  element.append(badge);
  return badge;
}
function settleBadge(badge, response) {
  if (!response.ok || !response.verdict) {
    badge.dataset.tier = "PENDING";
    const isInvalidated = response.error?.includes("Extension context invalidated") || response.error?.includes("reconnect");
    if (isInvalidated) {
      badge.textContent = "\u21BB refresh tab";
      badge.title = "SHOU extension was reloaded. Click or press Cmd+R (Ctrl+R) to refresh this tab and reconnect safety checking.";
      badge.style.cursor = "pointer";
      badge.onclick = () => location.reload();
    } else {
      badge.textContent = "\u26A0\uFE0E not checked";
      badge.title = `SHOU could not check this message: ${response.error ?? "unknown error"}`;
    }
    return;
  }
  const { tier, category, truthScore } = response.verdict;
  badge.dataset.tier = tier;
  badge.textContent = TIER_EMOJI[tier];
  badge.title = `${TIER_PLAIN[tier]}

Signal: ${category}` + (truthScore === null ? "" : `
Confidence: ${truthScore}/100`) + `

Scored inside a secure enclave. The message itself never left this device unredacted.`;
}
var seen = /* @__PURE__ */ new Set();
var MAX_SEEN = 4e3;
async function scoreNode(sessionId, site, node) {
  markScored(node.element);
  if (seen.has(node.key)) return;
  if (seen.size > MAX_SEEN) seen.clear();
  seen.add(node.key);
  styleOnce();
  const badge = attachBadge(node.element);
  const { text: redactedText, removed } = redact(node.text);
  const request = {
    type: "shou:score",
    sessionId,
    site,
    redactedText,
    redacted: removed
  };
  try {
    if (!chrome.runtime?.id) {
      throw new Error("Extension context invalidated. Please refresh this tab to reconnect.");
    }
    const response = await chrome.runtime.sendMessage(request);
    settleBadge(badge, response ?? { ok: false, error: "no response from SHOU" });
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    settleBadge(badge, {
      ok: false,
      error: msg.includes("Extension context invalidated") ? "Extension context invalidated. Please refresh this tab to reconnect." : msg
    });
  }
}
var SETTLE_MS = 2e4;
async function start(site) {
  let sessionId = null;
  let lastThreadKey = null;
  let everFound = false;
  const sweep = async () => {
    const root = site.root(document);
    if (!root) return;
    const threadKey = site.threadKey(document);
    if (!threadKey) return;
    everFound = true;
    if (threadKey !== lastThreadKey) {
      lastThreadKey = threadKey;
      sessionId = await sessionIdFor(threadKey);
      seen.clear();
    }
    for (const node of site.incoming(root)) {
      if (isScored(node.element)) continue;
      void scoreNode(sessionId, site.site, node);
    }
  };
  await sweep();
  setTimeout(() => {
    if (everFound) return;
    const failure = describeFailure(site, document);
    if (failure) console.warn(failure);
  }, SETTLE_MS);
  let queued = false;
  const observer = new MutationObserver(() => {
    if (queued) return;
    queued = true;
    setTimeout(() => {
      queued = false;
      void sweep();
    }, 250);
  });
  observer.observe(document.body, { childList: true, subtree: true });
  setInterval(() => void sweep(), 4e3);
}
