// src/shared.ts
var DEFAULT_SETTINGS = {
  circuitBreakerUrl: "http://127.0.0.1:4000",
  dashboardUrl: "http://127.0.0.1:4200",
  policyId: "",
  enabled: true
};
async function loadSettings() {
  const stored = await chrome.storage.local.get(DEFAULT_SETTINGS);
  return { ...DEFAULT_SETTINGS, ...stored };
}

// src/options.ts
var $ = (id) => document.getElementById(id);
function show(kind, message) {
  const status = $("status");
  status.className = `status ${kind}`;
  status.textContent = message;
}
function read() {
  return {
    policyId: $("policyId").value.trim(),
    circuitBreakerUrl: $("circuitBreakerUrl").value.trim() || DEFAULT_SETTINGS.circuitBreakerUrl,
    dashboardUrl: $("dashboardUrl").value.trim() || DEFAULT_SETTINGS.dashboardUrl,
    enabled: $("enabled").checked
  };
}
function write(settings) {
  $("policyId").value = settings.policyId;
  $("circuitBreakerUrl").value = settings.circuitBreakerUrl;
  $("dashboardUrl").value = settings.dashboardUrl;
  $("enabled").checked = settings.enabled;
}
async function main() {
  write(await loadSettings());
  $("save").addEventListener("click", () => {
    void chrome.storage.local.set(read()).then(() => show("ok", "Saved."));
  });
  $("fetch").addEventListener("click", () => {
    void (async () => {
      const base = read().dashboardUrl.replace(/\/$/, "");
      try {
        const response = await fetch(`${base}/api/config`);
        const body = await response.json();
        if (!response.ok) throw new Error(body.error ?? `dashboard returned ${response.status}`);
        if (!body.policyId) throw new Error("the dashboard has no policy id either \u2014 run seed-demo.ts");
        $("policyId").value = body.policyId;
        await chrome.storage.local.set(read());
        show("ok", `Policy id read from the dashboard and saved: ${body.policyId}`);
      } catch (error) {
        show("bad", `Could not read from ${base}: ${error instanceof Error ? error.message : String(error)}`);
      }
    })();
  });
  $("test").addEventListener("click", () => {
    void (async () => {
      const base = read().circuitBreakerUrl.replace(/\/$/, "");
      try {
        const response = await fetch(`${base}/health`);
        const body = await response.json();
        if (!response.ok) {
          throw new Error(body.status ?? `returned ${response.status}`);
        }
        show("ok", `Circuit breaker reachable, enclave ${body.status}.`);
      } catch (error) {
        show("bad", `${base} \u2014 ${error instanceof Error ? error.message : String(error)}`);
      }
    })();
  });
}
void main();
