// src/shared.ts
var DEFAULT_SETTINGS = {
  circuitBreakerUrl: "http://127.0.0.1:4000",
  dashboardUrl: "http://127.0.0.1:4200",
  policyId: "",
  enabled: true
};
var TIER_PLAIN = {
  LOW: "Nothing unusual in this chat.",
  MEDIUM: "Something about this chat looks off. A transfer here will wait, and your trusted contact will be told.",
  HIGH: "This looks like a scam. If you try to send money now, someone you trust has to approve it first."
};
var receiptUrlFor = (id) => `https://api.gonkarouter.io/v1/receipts/${id}`;

// ../redact/src/redact.ts
var PLACEHOLDERS = {
  otp: "[OTP]",
  nric: "[ID]",
  card: "[CARD]",
  account: "[ACCOUNT]",
  phone: "[PHONE]",
  email: "[EMAIL]",
  wallet: "[WALLET]",
  url: "[LINK]"
};
var RULES = [
  // Structured identifiers first — they contain digits that the looser
  // numeric rules below would otherwise chew into.
  { kind: "email", pattern: /\b[\w.+-]+@[\w-]+\.[\w.-]+\b/g },
  // Crypto addresses (EVM 40-hex and Sui 64-hex).
  { kind: "wallet", pattern: /\b0x[a-fA-F0-9]{40,64}\b/g },
  // One-time codes. "your TAC is 123456", "OTP: 8842". TAC is the
  // Malaysian term and appears constantly in local scam scripts.
  {
    kind: "otp",
    pattern: /\b(?:otp|tac|pin|passcode|verification code|code)\b[^0-9]{0,15}\d{4,8}\b/gi
  },
  // Malaysian NRIC: YYMMDD-PB-###G, with or without separators.
  { kind: "nric", pattern: /\b\d{6}[-\s]?\d{2}[-\s]?\d{4}\b/g },
  // International phone, matched WHOLE. Ordered before the numeric
  // rules so "+60 12-345 6789" cannot be redacted in part, which would
  // leave the country code and prefix behind — still identifying.
  { kind: "phone", pattern: /\+\d{1,3}[\s-]?\d(?:[\s-]?\d){5,12}(?!\d)/g },
  // Payment cards: 14–19 digits. Below that is treated as an account,
  // since local bank accounts are commonly 10–13.
  { kind: "card", pattern: /\b\d(?:[ -]?\d){13,18}(?!\d)/g },
  // Local mobile format, e.g. 012-345 6789.
  { kind: "phone", pattern: /\b0\d{1,2}[\s-]?\d{3,4}[\s-]?\d{4}(?!\d)/g },
  // Bank accounts: runs of 8–13 digits that survived the above, WITH or
  // WITHOUT separators — same shape as the card rule above.
  //
  // This used to be `\b\d{8,13}\b`, bare digits only, which left a hole
  // exactly where account numbers are usually written. `512088776655`
  // was stripped but `5140-2288-9911` — the same number, grouped the way
  // a person types one — passed through untouched and reached the model,
  // because it is too short for the 14–19 digit card rule and the account
  // rule could not see past the dashes.
  { kind: "account", pattern: /\b\d(?:[ -]?\d){7,12}(?!\d)/g }
];
function redactUrls(text, removed) {
  return text.replace(/\bhttps?:\/\/([^\s/]+)(\/\S*)?/gi, (_match, host, path) => {
    if (!path || path === "/") return `${PLACEHOLDERS.url}(${host})`;
    removed.url = (removed.url ?? 0) + 1;
    return `${PLACEHOLDERS.url}(${host})`;
  });
}
function protectAmounts(text) {
  const amounts = [];
  const masked = text.replace(
    /\b(?:rm|myr|sgd|usd|s\$|\$|£|€)\s?\d[\d,]*(?:\.\d{1,2})?\b/gi,
    (match) => {
      amounts.push(match);
      return `\0AMT${amounts.length - 1}\0`;
    }
  );
  return {
    text: masked,
    restore: (s) => s.replace(/\u0000AMT(\d+)\u0000/g, (_m, i) => amounts[Number(i)])
  };
}
function redact(message) {
  const removed = {};
  const { text: protectedText, restore } = protectAmounts(message);
  let out = redactUrls(protectedText, removed);
  for (const { kind, pattern } of RULES) {
    out = out.replace(pattern, (match) => {
      if (match.includes("[")) return match;
      removed[kind] = (removed[kind] ?? 0) + 1;
      return PLACEHOLDERS[kind];
    });
  }
  return { text: restore(out), removed };
}

// src/popup.ts
var $ = (id) => document.getElementById(id);
function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== void 0) node.textContent = text;
  return node;
}
function updateViewForVerdict(verdict, scoredCount) {
  const statusTitle = $("status-title");
  const statusDesc = $("status-desc");
  const coinEmblem = $("coin-emblem");
  const verdictContainer = $("verdict-container");
  const passiveStatus = $("chat-passive-status");
  if (!verdictContainer) return;
  verdictContainer.classList.remove("hidden");
  verdictContainer.innerHTML = "";
  passiveStatus?.classList.add("hidden");
  const isHigh = verdict.tier === "HIGH";
  const isMed = verdict.tier === "MEDIUM";
  if (isHigh) {
    if (statusTitle) {
      statusTitle.textContent = "SCAM DETECTED";
      statusTitle.classList.add("danger");
    }
    if (coinEmblem) coinEmblem.classList.add("danger");
    if (statusDesc) {
      statusDesc.textContent = "Someone is trying to pressure you. Do not send money. If you try, your own rules will hold it on Sui until someone you trust agrees.";
    }
  } else if (isMed) {
    if (statusTitle) {
      statusTitle.textContent = "CAUTION: CHECK FIRST";
      statusTitle.style.color = "#F59E0B";
    }
    if (statusDesc) {
      statusDesc.textContent = "This chat looks unusual. A transfer will wait for the cooling-off period she set, so there is time to check with family.";
    }
  } else {
    if (statusTitle) {
      statusTitle.textContent = "CHAT IS SAFE";
      statusTitle.style.color = "#10B981";
    }
    if (statusDesc) {
      statusDesc.textContent = "Normal conversation detected. Safe to chat and send money.";
    }
  }
  const box = element("div", `verdict-box ${verdict.tier}`);
  const title = element(
    "div",
    "verdict-title",
    isHigh ? "\u{1F6A8} High Risk Detected" : isMed ? "\u{1F7E0} Caution Recommended" : "\u{1F7E2} Safe Message"
  );
  const body = element("div", "verdict-body", TIER_PLAIN[verdict.tier]);
  box.append(title, body);
  if (verdict.reasoning) {
    const reason = element("div", "verdict-body");
    reason.style.marginTop = "6px";
    reason.style.opacity = "0.9";
    reason.style.fontSize = "12px";
    const label = document.createElement("strong");
    label.textContent = "AI spotted: ";
    reason.append(label, document.createTextNode(verdict.reasoning));
    box.append(reason);
  }
  const details = document.createElement("details");
  details.style.marginTop = "8px";
  details.style.fontSize = "11.5px";
  details.style.color = "var(--text-muted)";
  const summary = document.createElement("summary");
  summary.style.cursor = "pointer";
  summary.textContent = `Audit: scam risk ${verdict.truthScore ?? "N/A"}/100 (higher is worse) \xB7 Gonka receipts (${verdict.gonkaRequestIds.length})`;
  details.append(summary);
  if (verdict.gonkaRequestIds.length) {
    const ul = document.createElement("ul");
    ul.style.paddingLeft = "18px";
    ul.style.marginTop = "4px";
    for (const id of verdict.gonkaRequestIds) {
      const li = document.createElement("li");
      const a = document.createElement("a");
      a.href = receiptUrlFor(id);
      a.target = "_blank";
      a.rel = "noreferrer";
      a.style.color = "var(--blue-dark)";
      a.textContent = id;
      li.append(a);
      ul.append(li);
    }
    details.append(ul);
  }
  box.append(details);
  verdictContainer.append(box);
}
var TABS = [
  { btnId: "dock-tab-chats", panelId: "tab-chats" },
  { btnId: "dock-tab-wallet", panelId: "tab-wallet" },
  { btnId: "dock-tab-options", panelId: "tab-options" }
];
function wireTabs() {
  for (const { btnId } of TABS) {
    $(btnId)?.addEventListener("click", () => {
      for (const t of TABS) {
        $(t.btnId)?.classList.toggle("active", t.btnId === btnId);
        const panel = $(t.panelId);
        if (panel) panel.style.display = t.btnId === btnId ? "block" : "none";
      }
    });
  }
}
var MANUAL_SESSION_ID = "shou-popup-manual-paste";
function wireManualAnalyze() {
  const button = $("btn-deep-analyze");
  const input = $("chat-manual-input");
  const status = $("manual-analyze-status");
  const setStatus = (text, isError) => {
    if (!status) return;
    status.textContent = text;
    status.classList.remove("hidden");
    status.classList.toggle("error", isError);
  };
  button?.addEventListener("click", () => {
    void (async () => {
      const text = input?.value.trim();
      if (!text) {
        setStatus("Paste a message first.", true);
        return;
      }
      setStatus("Checking\u2026", false);
      const { text: redactedText, removed } = redact(text);
      const request = {
        type: "shou:score",
        sessionId: MANUAL_SESSION_ID,
        site: "popup-manual-paste",
        redactedText,
        redacted: removed
      };
      try {
        const response = await chrome.runtime.sendMessage(request);
        if (response?.ok && response.verdict) {
          updateViewForVerdict(response.verdict, 1);
          status?.classList.add("hidden");
        } else {
          setStatus(response?.error ?? "Could not check that message.", true);
        }
      } catch (error) {
        setStatus(error instanceof Error ? error.message : String(error), true);
      }
    })();
  });
}
function shortenId(id) {
  return id.length > 14 ? `${id.slice(0, 8)}\u2026${id.slice(-4)}` : id;
}
function updateOptionsView(settings) {
  const enabledEl = $("opt-enabled");
  if (enabledEl) enabledEl.textContent = settings.enabled ? "On" : "Off";
  const policyEl = $("opt-policy");
  if (policyEl) policyEl.textContent = settings.policyId ? shortenId(settings.policyId) : "Not set";
  const breakerEl = $("opt-breaker");
  if (breakerEl) breakerEl.textContent = settings.circuitBreakerUrl;
  const dashboardEl = $("opt-dashboard");
  if (dashboardEl) dashboardEl.textContent = settings.dashboardUrl;
  const dashboardLink = $("opt-dashboard-link");
  if (dashboardLink) dashboardLink.href = settings.dashboardUrl;
}
async function main() {
  wireTabs();
  wireManualAnalyze();
  const bannerClose = $("ext-banner-close");
  if (bannerClose) {
    bannerClose.onclick = () => {
      const b = $("ext-banner");
      if (b) b.style.display = "none";
    };
  }
  const navSettings = $("nav-settings");
  if (navSettings) {
    navSettings.onclick = (e) => {
      e.preventDefault();
      chrome.runtime?.openOptionsPage?.();
    };
  }
  $("btn-check-chat")?.addEventListener("click", () => {
    alert("SHOU actively scans incoming chat messages in WhatsApp and Messenger.");
  });
  $("btn-send-money")?.addEventListener("click", () => {
    window.open("http://localhost:3000/#simulator", "_blank");
  });
  $("btn-emergency-hold")?.addEventListener("click", () => {
    alert("Safety Pause triggered: All outgoing transfers are locked on Sui.");
  });
  let state = null;
  try {
    state = await chrome.runtime.sendMessage({ type: "shou:state" });
  } catch {
  }
  updateOptionsView(state?.settings ?? DEFAULT_SETTINGS);
  if (state?.sessions?.[0]) {
    const current = state.sessions[0];
    updateViewForVerdict(current.worst, current.scored);
  }
}
void main();
