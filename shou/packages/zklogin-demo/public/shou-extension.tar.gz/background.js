// src/shared.ts
var DEFAULT_SETTINGS = {
  circuitBreakerUrl: "http://127.0.0.1:4000",
  dashboardUrl: "http://127.0.0.1:4200",
  policyId: "",
  enabled: true
};
async function loadSettings() {
  const stored = await chrome.storage.local.get(DEFAULT_SETTINGS);
  return { ...DEFAULT_SETTINGS, ...stored };
}

// src/background.ts
var TIER_CODE = { LOW: 0, MEDIUM: 1, HIGH: 2 };
var sessions = /* @__PURE__ */ new Map();
var lastError = null;
function keepWorse(previous, next) {
  return TIER_CODE[next.tier] >= TIER_CODE[previous.tier] ? next : previous;
}
async function hashOf(text) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
}
function paintBadge() {
  let worst = null;
  for (const record of sessions.values()) {
    if (!worst || TIER_CODE[record.worst.tier] > TIER_CODE[worst]) worst = record.worst.tier;
  }
  const style = {
    HIGH: { text: "!", colour: "#b3261e" },
    MEDIUM: { text: "?", colour: "#8a5800" },
    LOW: { text: "\u2713", colour: "#0f7b4f" }
  };
  if (!worst) {
    void chrome.action.setBadgeText({ text: "" });
    return;
  }
  void chrome.action.setBadgeText({ text: style[worst].text });
  void chrome.action.setBadgeBackgroundColor({ color: style[worst].colour });
}
async function score(request) {
  const settings = await loadSettings();
  if (!settings.enabled) return { ok: false, error: "SHOU is switched off in its options" };
  if (!settings.policyId) {
    return {
      ok: false,
      error: "No policy id set. Open SHOU options and fetch it from the dashboard."
    };
  }
  const body = {
    sessionId: request.sessionId,
    message: request.redactedText,
    policyId: settings.policyId
  };
  let payload;
  try {
    const response = await fetch(`${settings.circuitBreakerUrl.replace(/\/$/, "")}/risk`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body)
    });
    payload = await response.json();
    if (!response.ok) throw new Error(payload.error ?? `circuit breaker returned ${response.status}`);
  } catch (error) {
    lastError = error instanceof Error ? error.message : String(error);
    return { ok: false, error: lastError };
  }
  lastError = null;
  if (!payload.tier) return { ok: false, error: "circuit breaker returned no tier" };
  const verdict = {
    tier: payload.tier,
    category: payload.category ?? "unknown",
    reasoning: payload.reasoning ?? "",
    truthScore: typeof payload.truthScore === "number" ? payload.truthScore : null,
    gonkaRequestIds: payload.gonkaRequestIds ?? [],
    redacted: request.redacted,
    messageHash: await hashOf(request.redactedText),
    atMs: Date.now()
  };
  const existing = sessions.get(request.sessionId);
  sessions.set(request.sessionId, {
    sessionId: request.sessionId,
    site: request.site,
    worst: existing ? keepWorse(existing.worst, verdict) : verdict,
    latest: verdict,
    scored: (existing?.scored ?? 0) + 1
  });
  paintBadge();
  return { ok: true, verdict };
}
chrome.runtime.onMessage.addListener((message, _sender, respond) => {
  if (message.type === "shou:score") {
    void score(message).then(respond);
    return true;
  }
  if (message.type === "shou:state") {
    void loadSettings().then((settings) => {
      const state = {
        settings,
        // Newest conversation first — the popup shows the one she is in.
        sessions: [...sessions.values()].sort((a, b) => b.latest.atMs - a.latest.atMs),
        lastError
      };
      respond(state);
    });
    return true;
  }
  return false;
});
chrome.runtime.onInstalled.addListener(() => {
  void chrome.storage.local.get(DEFAULT_SETTINGS).then((stored) => {
    void chrome.storage.local.set({ ...DEFAULT_SETTINGS, ...stored });
  });
});
